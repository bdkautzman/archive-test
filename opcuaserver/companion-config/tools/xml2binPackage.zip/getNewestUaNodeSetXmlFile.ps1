#
# @file getNewestUaNodeSetXmlFile.ps1
#
# @brief This script downloads the newest Opc.Ua.NodeSet2 from https://github.com/OPCFoundation/UA-Nodeset.
#
#
# SPDX-FileCopyrightText: Copyright (c) 2024 Bosch Rexroth AG
#
# The reproduction, distribution and utilization of this file as well as the communication of its contents to others
# without express authorization is prohibited. Offenders will be held liable for the payment of damages.
# All rights reserved in the event of the grant of a patent, utility model or design. 
#

Invoke-WebRequest -Uri "https://raw.githubusercontent.com/OPCFoundation/UA-Nodeset/latest/Schema/Opc.Ua.NodeSet2.xml" -OutFile "./Opc.Ua.NodeSet2.xml"