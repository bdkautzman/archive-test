This package enables the easy conversion of OPC UA NodeSet XML files into binary files. 
These binary files can then be loaded into the ctrlX OPC UA Server to provide the information models described in the NodeSet XML files.

To accomplish this, follow these steps:

  1) Extract all files from the xml2binPackage into a single folder
  2) Add all of your OPC UA NodeSet XML files (e.g., Opc.Ua.Di.NodeSet2.xml) to this folder. If required, also update your Opc.Ua.NodeSet2.xml. 
     You can download all versions of available OPC UA NodeSets at https://github.com/OPCFoundation/UA-Nodeset.
  3) Run the xml2binExtended.bat script from the command line, passing the OPC UA NodeSet XML files as arguments. 
     The order of dependency needs to be taken into account. 
     This means that the first nodeset should only depend on the standard OPC UA NodeSet (Opc.Ua.NodeSet2.xml). 
     The subsequent nodesets should only depend on nodesets that come before it in the sequence (to the left of it).
  4) Copy the generated binary files to the ctrlX App Data folder opcuaserver/companion-config/ and restart the ctrlX OPC UA Server.
  5) Proceed with the mapping process.

In addition to the binary files, text files are also generated. These text files contain the results of the generation process for the corresponding binary files.