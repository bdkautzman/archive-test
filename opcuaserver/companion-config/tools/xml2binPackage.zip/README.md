# xml2binExtended package

This package enables the easy conversion of OPC UA NodeSet XML files into binary files. 
These binary files can then be loaded into the ctrlX OPC UA Server to provide the information models described in the NodeSet XML files.

## How to use the xml2binExtended package

To accomplish this, follow these steps:

  1) Extract all files from the xml2binPackage into a single folder
  2) Add all of your OPC UA NodeSet XML files (e.g., Opc.Ua.Di.NodeSet2.xml) to this folder. If required, also update your Opc.Ua.NodeSet2.xml. 
     You can download all versions of available OPC UA NodeSets at https://github.com/OPCFoundation/UA-Nodeset.
  3) Run the xml2binExtended.bat script from the command line, passing the OPC UA NodeSet XML files as arguments. 
     The order of dependency needs to be taken into account. 
     This means that the first nodeset should only depend on the standard OPC UA NodeSet (Opc.Ua.NodeSet2.xml). 
     The subsequent nodesets should only depend on nodesets that come before it in the sequence (to the left of it).
  4) Copy the generated binary files to the ctrlX App Data folder opcuaserver/companion-config/ and restart the ctrlX OPC UA Server.
  5) Proceed with the mapping process.

In addition to the binary files, text files are also generated. These text files contain the results of the generation process for the corresponding binary files.

## Important directions for use

### General Terms of Use

In order to download and use the xml2binExtended package you have to accept the [Terms and Conditions for the Provision of Products of Bosch Rexroth AG Free of Charge](https://dc-corp.resource.bosch.com/media/xc/homepage/TC_for_provision_of_products_free_of_charge.pdf)

### Areas of use and application

The content (e.g. source code and related documents) of this package is intended to be used for configuration, parameterization, programming or diagnostics in combination with  Bosch Rexroth ctrlX OPC UA Server App.
Additionally, the specifications given in the "Areas of Use and Application" for ctrlX AUTOMATION devices used with the content of this repository do also apply.

### Unintended use

Any use of the xml2binExtended package in applications other than those specified above or under operating conditions other than those described in the documentation and the technical specifications is considered as "unintended". Furthermore, this software must not be used in any application areas not expressly approved by Bosch Rexroth.

## License

SPDX-FileCopyrightText: Copyright (c) 2026 Bosch Rexroth AG

## About

Please note that any trademarks, logos and pictures contained or linked to in this Software are owned by or copyright © Bosch Rexroth AG 2021-2024 and not licensed under the Software's license terms.

<https://www.boschrexroth.com>

Bosch Rexroth AG  
Bgm.-Dr.-Nebel-Str. 2  
97816 Lohr am Main  
GERMANY
