rem
rem @file xml2binExtended.bat
rem
rem @brief This script is used to convert the OPC UA NodeSet XML files to binary files using the xml2bin.exe tool.
rem
rem  Run the xml2binExtended.bat script from the command line, passing the OPC UA NodeSet XML files as arguments. 
rem  The order of dependency needs to be taken into account. 
rem  This means that the first nodeset should only depend on the standard OPC UA NodeSet (Opc.Ua.NodeSet2.xml). 
rem  The subsequent nodesets should only depend on nodesets that come before it in the sequence (to the left of it).
rem
rem SPDX-FileCopyrightText: Copyright (c) 2024 Bosch Rexroth AG
rem
rem The reproduction, distribution and utilization of this file as well as the communication of its contents to others
rem without express authorization is prohibited. Offenders will be held liable for the payment of damages.
rem All rights reserved in the event of the grant of a patent, utility model or design. 

@echo off
setlocal enabledelayedexpansion

set argCount=0
for %%x in (%*) do (
   set /A argCount+=1
   set "argVec[!argCount!]=%%~x"
)

echo Number of processed arguments: %argCount%

for /L %%i in (1,1,%argCount%) do (
echo %%i - "!argVec[%%i]!"
set "xmlModels=!xmlModels! !argVec[%%i]!"
set /A iCounter = %%i+1
set /A prefix = %%i-1
if !prefix! lss 10 (
    set prefix=0!prefix!
) else (
    set prefix=!prefix!
)
set output=!argVec[%%i]:~0,-4!
call xml2bin.exe -o !prefix!_!output!.bin -i!iCounter! Opc.Ua.NodeSet2.xml !xmlModels! > !prefix!_!output!.txt
echo xml2bin.exe -o !prefix!_!output!.bin -i!iCounter! Opc.Ua.NodeSet2.xml !xmlModels! saved in !prefix!_!output!.txt

)

